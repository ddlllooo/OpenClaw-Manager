// Local UI-only scheduler. Does not intercept global timers, RPC or sockets.
export function createVisibleClockRuntime(env) {
  const {document: doc, window: win, setTimeout: later, clearTimeout: cancel, now} = env;
  const jobs = new Set();
  let frozen = false, listening = false;
  function changed() { for (const job of [...jobs]) job.update(); }
  function hide() { frozen = true; changed(); }
  function show() { frozen = false; changed(); }
  function listen() {
    if (listening) return;
    listening = true;
    doc.addEventListener('visibilitychange', changed);
    win.addEventListener('pagehide', hide); win.addEventListener('pageshow', show);
  }
  function unlisten() {
    if (jobs.size || !listening) return;
    listening = false;
    doc.removeEventListener('visibilitychange', changed);
    win.removeEventListener('pagehide', hide); win.removeEventListener('pageshow', show);
  }
  return function visibleClock(options) {
    let timer = null, due = 0, disposed = false, active = null, ticking = false;
    let target = null, intersecting = true;
    const observer = env.IntersectionObserver ? new env.IntersectionObserver(entries => {
      const entry = entries.find(entry => entry.target === target);
      if (entry) { intersecting = entry.isIntersecting; update(); }
    }) : null;
    function element() { return typeof options.element === 'function' ? options.element() : options.element; }
    function wanted() {
      if (disposed || frozen || doc.visibilityState !== 'visible' || options.enabled?.() === false) return false;
      const next = element();
      if (next !== target) {
        observer?.disconnect(); target = next; intersecting = true;
        if (target) observer?.observe(target);
      }
      if (target && !target.isConnected) { dispose(); return false; }
      return !target || (intersecting && target.getClientRects().length > 0);
    }
    function clear() { if (timer !== null) cancel(timer); timer = null; due = 0; }
    function interval() { return Math.max(16, typeof options.interval === 'function' ? options.interval() : options.interval); }
    function arm(delay = interval()) {
      if (!active || disposed) return;
      const next = now() + delay;
      if (timer !== null && due <= next) return;
      clear(); due = next;
      timer = later(() => { timer = null; due = 0; run(); }, delay);
    }
    function run() {
      if (!wanted()) { update(); return; }
      ticking = true;
      try { options.tick(); } finally { ticking = false; if (wanted()) arm(); else update(); }
    }
    function update() {
      const next = wanted();
      if (next !== active) {
        active = next; options.onActive?.(active);
        if (active) arm(0); else clear();
      } else if (active && !ticking) arm();
    }
    function dispose() {
      if (disposed) return;
      disposed = true; clear(); observer?.disconnect();
      if (active) { active = false; options.onActive?.(false); }
      options.onDispose?.(); jobs.delete(job); unlisten();
    }
    const job = {update, dispose, wake(delay = 33) { update(); if (active) arm(delay); }};
    jobs.add(job); listen(); update(); return job;
  };
}
export const ocVisibleClock = typeof document === 'undefined' ? null : createVisibleClockRuntime({
  document, window, IntersectionObserver: globalThis.IntersectionObserver,
  setTimeout: window.setTimeout.bind(window), clearTimeout: window.clearTimeout.bind(window), now: Date.now,
});
